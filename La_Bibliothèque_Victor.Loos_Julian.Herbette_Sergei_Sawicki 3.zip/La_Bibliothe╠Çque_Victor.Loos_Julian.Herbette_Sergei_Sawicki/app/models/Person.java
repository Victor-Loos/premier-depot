package models ;

import java.util.*;
import io.ebean.*;
import javax.persistence.*;

import play.data.validation.*;


@Entity
public class Person extends Model {
  
private static final long serialVersionUID = 1L;

@Id
public long id;    
public String firstname ;
public int age ; 
public String password;
    
    public Person(String firstname, int age, String password){
        this.firstname=firstname;
        this.age=age;
        this.password=password;
    }
    
    public Person(){   
    }
    
    
    
    public String getFirstname(){
        return this.firstname;
    }
    
    public int getAge(){
        return this.age;
    }
    
    public long getId(){
        return this.id;
    }
    
    
    
    public void setId(long id){
        this.id = id;
    }
    
    public void setAge(int age){
        this.age = age;
    }
    
    public void setFirstname(String firstname){
        this.firstname = firstname;
    }
    
    public static Finder<Long, Person> find = new Finder<Long,Person>(Person.class);
}