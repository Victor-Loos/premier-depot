package controllers;

import play.mvc.*;

import models.*;

import javax.inject.Inject;
import play.i18n.MessagesApi;
import play.data.*;

import views.html.*;
import play.data.validation.Constraints.*;

import java.util.List;
/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController2 extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */    

    @Inject
    FormFactory formFactory;
    Form<Livre> livreForm;
    MessagesApi messagesApi;
    
    @Inject
    public HomeController2(FormFactory formFactory, MessagesApi messagesApi){
        this.livreForm = formFactory.form(Livre.class);
        this.messagesApi = messagesApi;
    }

    


    
    // public Result ajoutLivre(Http.Request request){
    //     // livreForm = formFactory.form(Livre.class) ;
    //     return ok(views.html.ajoutLivre.render(livreForm,request,messagesApi.preferred(request)));
    // } 
    // // return ok(sayhelloform.render


    // public Result ajoutLivre(Http.Request request) {
    //    final Form<Livre> pForm = livreForm.bindFromRequest(request) ; 
    // //    if (pForm.hasErrors()){
    //   //      return badRequest(sayhelloform.render(pForm,request, messagesApi.preferred(request)));
    // //    }
    // //    else{
    //         Livre a = pForm.get();
    //         a.save();
    //     return redirect(routes.HomeController2.ajoutLivre()) ;
        
    // //    }
    // }


    /**
    voir le formulaire
    */
    public Result ajoutLivre (Http.Request request) {
        livreForm = formFactory.form(Livre.class) ;
        return ok(ajoutLivre.render(livreForm, request, messagesApi.preferred(request))) ; 
        // return redirect(routes.HomeController.Accueil()) ;

    }





    
    public Result livreOk(Http.Request request){
        Form<Livre> lform = livreForm.bindFromRequest(request);
        if (lform.hasErrors()){
            return badRequest(ajoutLivre.render(lform, request, messagesApi.preferred(request)));
        } else {
        Livre livre = lform.get();
            livre.save();
        return redirect(routes.HomeController2.allLivre());
        }
    
    }
 
    public Result allLivre(){
        List<Livre> liste = Livre.find.all();
        return ok(allLivre.render(liste));
    }
    
    public Result showLivre(Long id){
        Livre livre = Livre.find.byId(id);
        return ok(showLivre.render(livre));
    }
    
    public Result deleteLivre(Long id){
        Livre livre = Livre.find.byId(id);
        livre.delete();
        return redirect (routes.HomeController2.allLivre());
    }
    
    public Result updateLivre(Long id, Http.Request request){
         Livre livre = Livre.find.byId(id);
         livreForm = livreForm.fill(livre);
         return ok(updateLivre.render(livreForm, id, request, messagesApi.preferred(request)));
    }
    
     public Result updateOk(Long id, Http.Request request){
         Form<Livre> lform = livreForm.bindFromRequest(request);
        if (lform.hasErrors()){
            return badRequest(updateLivre.render(lform, id, request, messagesApi.preferred(request)));
        } else {
        Livre livre = lform.get();
            livre.setId(id);
            livre.update();
        return redirect(routes.HomeController2.allLivre());
        }
    }
}
